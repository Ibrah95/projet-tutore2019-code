import { WORLD_SIZE } from '../config'
import { createText } from './utils'
import fileLoader from '../config/fileloader'
import createWorld from './world/createWorld'
import player from './player'
import newPlayer from './sockets/newPlayer'
import { WINDOW_HEIGHT,WINDOW_WIDTH } from './../config'

const SERVER_IP = 'localhost:8000/'
let socket = null
let otherPlayers = {}
let random
class Game extends Phaser.State {
  constructor () {
    super()
    this.player = {}
    //this.physics.enable(sprite, Phaser.Physics.ARCADE)
  }

  preload () {
    // Loads files
    fileLoader(this.game)
  }

  create () {
    const { width, height } = WORLD_SIZE
    // Creates the world
    createWorld(this.game)
    // Connects the player to the server
    socket = io(SERVER_IP)
    // Creates the player passing the X, Y, game and socket as arguments
    //this.player = player(width / 2, Math.random() * height, this.game, socket)

    //fonction pour apparition random :
    random = Math.random()* (10-1)+1
    //1 2 3   4 5 6 7   8 9 10
    console.log(`${random} random`)
    if(random <= 3 ) {
      
            console.log(`${random} random<= 3`)
            this.player = player( width/3 , Math.random() * ((WINDOW_HEIGHT - 100) -100 ) + 100 , this.game, socket)
           
    }
    //if inférieur ou egal à trois :
    if(random >= 4 && random <= 7 ) {
            console.log(`${random}  4<=random<=7`)
            this.player = player( width/2 , Math.random() * ((WINDOW_HEIGHT - 100) -100 ) + 100 , this.game, socket)
            
    }

    if(random >= 8  && random <= 10 ){
       console.log(`${random} 8<=random<=10`)
            this.player = player( width , Math.random() * ((WINDOW_HEIGHT - 100) -100 ) + 100 , this.game, socket)
    }


    //this.player = player( width /2 , Math.random() * ((WINDOW_HEIGHT - 100) -100 ) + 100 , this.game, socket)
    // Creates the player name text
    this.player.playerName = createText(this.game, this.player.sprite.body)
    // Creates the player speed text
    this.player.speedText = createText(this.game, this.player.sprite.body)

    // Sends a new-player event to the server
    newPlayer(socket, this.player)

    // Configures the game camera
    this.game.camera.x = this.player.sprite.x - 800 / 2
    this.game.camera.y = this.player.sprite.y - 600 / 2

    // Scale game to fit the entire window
    this.game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL
  }

  update () {
    this.player.drive(this.game)

    // Move the camera to follow the player
    let cameraX = this.player.sprite.x - 800 / 2
    let cameraY = this.player.sprite.y - 600 / 2
    this.game.camera.x += (cameraX - this.game.camera.x) * 0.08
    this.game.camera.y += (cameraY - this.game.camera.y) * 0.08
  }
}

export default Game
